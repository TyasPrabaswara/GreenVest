import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Node;

public class create1_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    void uploadButton(ActionEvent event){
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Text Files", ".txt", ".pdf"),
            new FileChooser.ExtensionFilter("Image Files", ".png", ".jpg", "*.gif"),
            new FileChooser.ExtensionFilter("Audio Files", ".wav", ".mp3", "*.aac"),
            new FileChooser.ExtensionFilter("All Files", ".")
        );
    
        File selectedFile = fileChooser.showOpenDialog((Stage) ((Node) event.getSource()).getScene().getWindow());
        if (selectedFile != null) {
            Button uploadButton = new Button(); 
            uploadButton.setText("Seccess Upload!");
        }
    }

    @FXML
    private void closeButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void createButton (ActionEvent event) throws IOException{
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Create Project");
        alert.setHeaderText("You're about create project!");
        alert.setContentText("Are you sure to make this priject?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

}
