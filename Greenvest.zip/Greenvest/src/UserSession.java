import java.io.File;
import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class UserSession {
    private static User currentUser;
    private static List<User> users;

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static void clear() {
        currentUser = null;
    }

    public static void setUsers(List<User> userList) {
        users = userList;
    }

    public static void saveCurrentUserState(String filePath) {
        if (currentUser != null && users != null) {
            for (User user : users) {
                if (user.getUsername().equals(currentUser.getUsername())) {
                    user.setPhoneNumber(currentUser.getPhoneNumber());
                    user.setEmail(currentUser.getEmail());
                    user.setAccountBalance(currentUser.getAccountBalance());
                }
            }
            saveUsersToJson(filePath);
        }
    }

    private static void saveUsersToJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File(filePath), users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
}
