import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Node;

public class dashboardPage1_Controller implements Initializable {

    XYChart.Series <String, Integer> month = new XYChart.Series();

    @FXML
    private LineChart monthChart;

    @FXML
    private Label profileNameLabel;

    @FXML
    private Label accBalanceLabel;

    private Stage stage;
    private Scene scene;
    private Parent parent;

    public void initializeUserData(){
        User currentUser = UserSession.getCurrentUser();
        if(currentUser != null){
        profileNameLabel.setText(currentUser.getUsername());
        accBalanceLabel.setText("Rp " + String.valueOf(currentUser.getAccountBalance()));
        }
    }

    @FXML
    private void homeButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void projectButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void dashboardButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void notificationButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("notificationPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void profileButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("profile1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void createButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("create1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
        transition.setFromValue(0);
        transition.setToValue(1);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void reportButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("report1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
        transition.setFromValue(0);
        transition.setToValue(1);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void showButton(ActionEvent event){
        month.getData().add(new XYChart.Data<>("Jan", 20000));
        month.getData().add(new XYChart.Data<>("Feb", 15000));
        month.getData().add(new XYChart.Data<>("Mar", 10000));
        month.getData().add(new XYChart.Data<>("Apr", 16000));
        month.getData().add(new XYChart.Data<>("May", 9000));
        month.getData().add(new XYChart.Data<>("jun", 5000));
        month.getData().add(new XYChart.Data<>("Jul", 4500));
        month.getData().add(new XYChart.Data<>("Aug", 7000));
        month.getData().add(new XYChart.Data<>("Sep", 21000));
        month.getData().add(new XYChart.Data<>("Okt", 22000));
        monthChart.setAnimated(false);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        monthChart.getData().add(month);
        initializeUserData();
    }    
    
}
