import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.util.Duration;

public class login1_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    private void loginButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
        transition.setFromX(300);
        transition.setToX(0);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void registerButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("login2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void forgotButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("login3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void logoutButton (ActionEvent event) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you want to exit the application?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
