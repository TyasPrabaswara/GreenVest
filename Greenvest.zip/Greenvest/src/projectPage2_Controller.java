import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;

public class projectPage2_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    TextField amountField;

    @FXML
    private Label profileNameLabel;

    @FXML
    private Label accBalanceLabel;

    double finalBalance;

    

    public void initializeUserData(){
        User currentUser = UserSession.getCurrentUser();
        if(currentUser != null){
        profileNameLabel.setText(currentUser.getUsername());
        accBalanceLabel.setText("Rp " + String.valueOf(currentUser.getAccountBalance()));
        }
    }

    @FXML
    private void homeButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void projectButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void dashboardButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void notificationButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("notificationPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void profileButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("profile1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void investButtonSetla(ActionEvent event) throws IOException {
        String amount = amountField.getText();
        User currentUser = UserSession.getCurrentUser();

        if (Integer.parseInt(amount)==0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error Amount");
            alert.setHeaderText("Please enter an amount.");
            alert.setContentText("You must enter an amount to proceed.");

            if (alert.showAndWait().get() == ButtonType.OK) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage2.fxml"));
                Parent root = loader.load();
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        }
        } else {
            finalBalance = currentUser.getAccountBalance() - Double.parseDouble(amount);
            updateUserBalance(finalBalance);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage5.fxml"));
            parent = loader.load();
            projectPage5_Controller projectpage5_controller = loader.getController();
            projectpage5_controller.displayAmount(amount);
            loader.setController(projectpage5_controller);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void investButtonEco(ActionEvent event) throws IOException {
        String amount = amountField.getText();
        User currentUser = UserSession.getCurrentUser();

        if (Integer.parseInt(amount)==0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error Amount");
            alert.setHeaderText("Please enter an amount.");
            alert.setContentText("You must enter an amount to proceed.");

            if (alert.showAndWait().get() == ButtonType.OK) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage3.fxml"));
                Parent root = loader.load();
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        }
        } else {
            finalBalance = currentUser.getAccountBalance() - Double.parseDouble(amount);
            updateUserBalance(finalBalance);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage7.fxml"));
            parent = loader.load();
            projectPage7_Controller projectpage7_controller = loader.getController();
            projectpage7_controller.displayAmount(amount);
            loader.setController(projectpage7_controller);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void investButtonFreshWater(ActionEvent event) throws IOException {
        String amount = amountField.getText();
        User currentUser = UserSession.getCurrentUser();

        if (Integer.parseInt(amount)==0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error Amount");
            alert.setHeaderText("Please enter an amount.");
            alert.setContentText("You must enter an amount to proceed.");

            if (alert.showAndWait().get() == ButtonType.OK) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage4.fxml"));
                Parent root = loader.load();
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        }
        } else {
            finalBalance = currentUser.getAccountBalance() - Double.parseDouble(amount);
            updateUserBalance(finalBalance);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("projectPage6.fxml"));
            parent = loader.load();
            projectPage6_Controller projectpage6_controller = loader.getController();
            projectpage6_controller.displayAmount(amount);
            loader.setController(projectpage6_controller);

            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
        }
    }

    public void updateUserBalance(double newBalance) {
        User currentUser = UserSession.getCurrentUser();
        if (currentUser != null) {
            currentUser.setAccountBalance(newBalance);
            UserSession.saveCurrentUserState("users.json");
            accBalanceLabel.setText(String.valueOf(currentUser.getAccountBalance()));
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeUserData();
    }    
    
}
