import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.SecretKey;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Queue;

public class LoginControllerMOD2 {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    @FXML
    private TextField registerUsernameField;
    @FXML
    private PasswordField registerPasswordField;
    @FXML
    private TextField registerPhoneNumberField;
    @FXML
    private TextField registerEmailField;

    private Stage stage;
    private Scene scene;
    private Parent parent;


    private List<User> users;
    private SecretKey secretKey;

    @FXML
    public void initialize() {
        loadUsersFromJson("users.json");
        try {
            // Load the key from a file or generate a new one
            File keyFile = new File("aes.key");
            if (keyFile.exists()) {
                byte[] keyBytes = Files.readAllBytes(Paths.get("aes.key"));
                secretKey = AESEncryption.stringToKey(new String(keyBytes));
            } else {
                secretKey = AESEncryption.generateKey(128);
                Files.write(Paths.get("aes.key"), AESEncryption.keyToString(secretKey).getBytes());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void transitionToHomePage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
        transition.setFromX(300);
        transition.setToX(0);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();

        for (User user : users) {
            try {
                String decryptedPassword = AESEncryption.decrypt(user.getPassword(), secretKey);
                if ((user.getUsername().equals(username) || user.getEmail().equals(username)) && decryptedPassword.equals(password)) {
                    messageLabel.setText("Login Successful");
                    System.out.println("Success");
                    saveUsersToJson("users.json");

                    UserSession.setCurrentUser(user);

                    // Transition to the next scene
                    Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);

                    TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
                    transition.setFromX(300);
                    transition.setToX(0);
                    transition.play();

                    stage.setScene(scene);
                    stage.show();
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        messageLabel.setText("Invalid username or password");
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        String username = registerUsernameField.getText();
        String password = registerPasswordField.getText();
        String phoneNumber = registerPhoneNumberField.getText();
        String email = registerEmailField.getText();

        for (User user : users) {
            if (user.getUsername().equals(username)) {
                messageLabel.setText("Username already exists");
                return;
            }
        }

        try {
            String encryptedPassword = AESEncryption.encrypt(password, secretKey);
            User newUser = new User(username, encryptedPassword, phoneNumber, email, 0.0);
            users.add(newUser);
            saveUsersToJson("users.json");
            messageLabel.setText("Registration Successful");
            UserSession.setCurrentUser(newUser);
            transitionToHomePage(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadUsersFromJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File file = new File(filePath);
            if (file.exists()) {
                User[] userArray = mapper.readValue(file, User[].class);
                users = new ArrayList<>(Arrays.asList(userArray));
            } else {
                users = new ArrayList<>();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveUsersToJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File(filePath), users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void loginButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
        transition.setFromX(300);
        transition.setToX(0);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void registerButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login2.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void forgotButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login3.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void logoutButton(ActionEvent event) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you want to exit the application?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            UserSession.clear();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }
}
