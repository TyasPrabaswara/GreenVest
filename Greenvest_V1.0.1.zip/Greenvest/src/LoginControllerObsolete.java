import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class LoginControllerObsolete {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    private Stage stage;
    private Scene scene;
    private Parent parent;

    
    private List<User> users;

    @FXML
    public void initialize(){
    loadUsersFromJson("users.json");
    }

    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();
        

        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                messageLabel.setText("Login Successful");
                System.out.println("Success");
                saveUsersToJson("users.json");

                // Transition to the next scene
                Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);

                TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
                transition.setFromX(300);
                transition.setToX(0);
                transition.play();

                stage.setScene(scene);
                stage.show();
                return;
            }
        }
        messageLabel.setText("Invalid username or password");
    }


    private void loadUsersFromJson(String filePath){
        ObjectMapper mapper = new ObjectMapper();
        try{
            File file = new File(filePath);
            User[] userArray = mapper.readValue(file, User[].class);
            users = Arrays.asList(userArray);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    @FXML
    private void loginButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
        transition.setFromX(300);
        transition.setToX(0);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void registerButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("login2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void forgotButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("login3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void logoutButton (ActionEvent event) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you want to exit the application?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    private void saveUsersToJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            // Save the users list to the file
            mapper.writeValue(new File(filePath), users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
}