import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import javax.crypto.SecretKey;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Text;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.util.Duration;

public class profile1_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    private Label nameLabel;

    @FXML
    private Label phoneNumberLabel;

    @FXML
    private Label emailLabel;

    @FXML
    private Label profileNameLabel;

    @FXML
    private Label accBalanceLabel;

    @FXML
    private TextField nameChangeField;

    @FXML
    private TextField phoneNumberChangeField;

    @FXML
    private TextField emailChangeField;

    @FXML
    private PasswordField oldPasswordField;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private TextField accountBalanceField;


    @FXML
    private Label changeNotif;

    private SecretKey secretKey;

    @FXML
    private void initialize(){
        try {
            // Load the key from a file or generate a new one
            File keyFile = new File("aes.key");
            if (keyFile.exists()) {
                byte[] keyBytes = Files.readAllBytes(Paths.get("aes.key"));
                secretKey = AESEncryption.stringToKey(new String(keyBytes));
            } else {
                secretKey = AESEncryption.generateKey(128);
                Files.write(Paths.get("aes.key"), AESEncryption.keyToString(secretKey).getBytes());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializeUserData(){
        User currentUser = UserSession.getCurrentUser();
        if(currentUser != null){
        profileNameLabel.setText(currentUser.getUsername());
        accBalanceLabel.setText("Rp. " + String.valueOf(currentUser.getAccountBalance()));
        nameChangeField.setText(currentUser.getUsername());
        phoneNumberChangeField.setText(currentUser.getPhoneNumber());
        emailChangeField.setText(currentUser.getEmail());
        //passwordChangeField.setText(currentUser.getPassword());
        }
    }

    @FXML
    private void homeButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void projectButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void dashboardButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void notificationButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("notificationPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void profileButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("profile1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void logoutButton (ActionEvent event) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you want to exit the application?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            UserSession.clear();
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    
    private void updUserProfile(){
        User currentUser = UserSession.getCurrentUser();
        profileNameLabel.setText(currentUser.getUsername());
        phoneNumberChangeField.setText(currentUser.getPhoneNumber());
        emailChangeField.setText(currentUser.getEmail());
        accBalanceLabel.setText("Rp. " + String.valueOf(currentUser.getAccountBalance()));
    }

    @FXML
    private void saveNewUserInfo(ActionEvent event){
        User currentUser = UserSession.getCurrentUser();
        currentUser.setUsername(nameChangeField.getText());
        currentUser.setPhoneNumber(phoneNumberChangeField.getText());
        currentUser.setEmail(emailChangeField.getText());
        handleChangePassword();
        addFunds();
        UserSession.saveCurrentUserState("users.json");
        changeNotif.setText("Account info successfully changed!");
        updUserProfile();
    }

    @FXML
    private void addFunds(){
        User currentUser = UserSession.getCurrentUser();
        double newFundAmount = Double.parseDouble(accountBalanceField.getText());
        if(newFundAmount<=0){
            changeNotif.setText("Invalid amount of funds.");
        }else if(accountBalanceField.getText()==null || newFundAmount > 0){
            double newBal = currentUser.getAccountBalance() + newFundAmount;
            currentUser.setAccountBalance(newBal);
        }
    }

    public void changeUserPassword(String oldPassword, String newPassword) {
        boolean isPasswordChanged = UserSession.changePassword(oldPassword, newPassword, secretKey);
        if (isPasswordChanged) {
            // Provide feedback to the user
            System.out.println("Password changed successfully.");
        } else {
            // Provide feedback to the user
            System.out.println("Password change failed. Please check your old password.");
        }
    }

    @FXML
    private void handleChangePassword() {
        String oldPassword = oldPasswordField.getText();
        String newPassword = newPasswordField.getText();

        // Assuming HomePageController is accessible and initialized
        changeUserPassword(oldPassword, newPassword);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initialize();
        initializeUserData();
    }
    
}
