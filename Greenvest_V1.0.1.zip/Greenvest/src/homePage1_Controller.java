import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.util.Duration;

public class homePage1_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    private Label profileNameLabel;

    @FXML
    private Label accBalanceLabel;

    public void initializeUserData(){
        User currentUser = UserSession.getCurrentUser();
        if(currentUser != null){
        profileNameLabel.setText(currentUser.getUsername());
        accBalanceLabel.setText("Rp. " + String.valueOf(currentUser.getAccountBalance()));
        }
    }

    @FXML
    private void homeButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void projectButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void dashboardButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("dashboardPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void notificationButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("notificationPage1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void profileButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("profile1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void telsaButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
        transition.setFromValue(0);
        transition.setToValue(1);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void ecoButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
        transition.setFromValue(0);
        transition.setToValue(1);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void freshButton (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("projectPage4.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
        transition.setFromValue(0);
        transition.setToValue(1);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeUserData();
    }    
    
}
