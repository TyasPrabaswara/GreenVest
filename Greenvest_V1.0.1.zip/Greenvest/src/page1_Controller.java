import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Node;

public class page1_Controller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent parent;

    @FXML
    private Label profileNameLabel;

    @FXML
    private Label emaiLabel;

    @FXML
    private Label phoneNumberLabel;

    @FXML
    private Label nameLabel;

    private void transitionToHomePage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homePage1.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        TranslateTransition transition = new TranslateTransition(Duration.seconds(0.2), root);
        transition.setFromX(300);
        transition.setToX(0);
        transition.play();

        stage.setScene(scene);
        stage.show();
    }

    private void transitionToLogin (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("login1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    private void nextButton (ActionEvent event) throws IOException{
        User currentUser = UserSession.getCurrentUser();
        if(currentUser != null){
            transitionToHomePage(event);
        }else{
            
            Parent root = FXMLLoader.load(getClass().getResource("login1.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            FadeTransition transition = new FadeTransition(Duration.seconds(0.3), root);
            transition.setFromValue(0);
            transition.setToValue(1);
            transition.play();
            stage.setScene(scene);
            stage.show();
        }
        
    }

    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

}
